package business;

import java.util.Calendar;

import beans.Driver;
import beans.Policy;
import beans.Vehicle;

public class PolicyBO {

	public static int calculatePremium(Policy policy) {

		float premium = 0;

		for (Vehicle v : policy.getVehicles()) {
			premium += calculatePremium(v);
		}

		for (Driver d : policy.getDrivers()) {
			premium += calculatePremium(d, policy.getEffectiveDate());
		}

		return Math.round(premium);
	}

	static float calculatePremium(Vehicle vehicle) {

		float premium = 50;

		switch (vehicle.getMake()) {
		case "Audi":
		case "BMW":
		case "Mercedes":
			premium *= 2.0;
			break;

		case "Cadillac":
		case "Lexus":
		case "Infiniti":
			premium *= 1.75;
			break;
			
		case "Toyota":
		case "Honda":
		case "Volkswagen":
			premium *= 1.25;
			break;

		case "Chevrolet":
		case "Ford":
		case "Hyundai":
			premium *= 0.75;
			break;

		default:
			premium *= 1.0;
		}

		return premium;
	}

	static float calculatePremium(Driver driver, Calendar effectiveDate) {

		float premium = 50;

		int age = effectiveDate.get(Calendar.YEAR) - driver.getBirthDate().get(Calendar.YEAR);

		if (age < 18) {
			premium *= 2.5;
		} else if (age < 25) {
			premium *= 2;
		} else if (age < 35) {
			premium *= 1;
		} else if (age < 45) {
			premium *= 0.75;
		} else {
			premium *= 0.6;
		}

		return premium;
	}
}
