package beans;


public class Vehicle {

	private String make;
	private String model;
	private int year;
	private String usage;
	private int milesPerYear;
	private Coverage coverage;
	
	public Vehicle() {
	}

	public Vehicle(String make, String model, int year, String usage, int milesPerYear, Coverage coverage) {
		super();
		this.make = make;
		this.model = model;
		this.year = year;
		this.usage = usage;
		this.milesPerYear = milesPerYear;
		this.coverage = coverage;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	public int getMilesPerYear() {
		return milesPerYear;
	}

	public void setMilesPerYear(int milesPerYear) {
		this.milesPerYear = milesPerYear;
	}

	public Coverage getCoverage() {
		return coverage;
	}

	public void setCoverage(Coverage coverage) {
		this.coverage = coverage;
	}
}
