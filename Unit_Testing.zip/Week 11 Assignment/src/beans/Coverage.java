package beans;

public class Coverage {

	private int liabilityLimit;
	private int propertyDamageLimit;
	private int uninsuredMotoristLimit;

	public Coverage() {
	}

	public Coverage(int liabilityLimit, int propertyDamageLimit, int uninsuredMotoristLimit) {
		super();
		this.liabilityLimit = liabilityLimit;
		this.propertyDamageLimit = propertyDamageLimit;
		this.uninsuredMotoristLimit = uninsuredMotoristLimit;
	}

	public int getLiabilityLimit() {
		return liabilityLimit;
	}

	public void setLiabilityLimit(int liabilityLimit) {
		this.liabilityLimit = liabilityLimit;
	}

	public int getPropertyDamageLimit() {
		return propertyDamageLimit;
	}

	public void setPropertyDamageLimit(int propertyDamageLimit) {
		this.propertyDamageLimit = propertyDamageLimit;
	}

	public int getUninsuredMotoristLimit() {
		return uninsuredMotoristLimit;
	}

	public void setUninsuredMotoristLimit(int uninsuredMotoristLimit) {
		this.uninsuredMotoristLimit = uninsuredMotoristLimit;
	}
}
