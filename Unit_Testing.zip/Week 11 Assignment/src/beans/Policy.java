package beans;

import java.util.Calendar;
import java.util.List;

public class Policy {

	private String policyNumber;
	private Calendar effectiveDate;
	private int deductible;
	private String state;
	private List<Driver> drivers;
	private List<Vehicle> vehicles;

	public Policy() {
	}

	public Policy(String policyNumber, Calendar effectiveDate, int deductible, String state, List<Driver> drivers,
			List<Vehicle> vehicles) {
		super();
		this.policyNumber = policyNumber;
		this.effectiveDate = effectiveDate;
		this.deductible = deductible;
		this.state = state;
		this.drivers = drivers;
		this.vehicles = vehicles;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Calendar getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Calendar effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public int getDeductible() {
		return deductible;
	}

	public void setDeductible(int deductible) {
		this.deductible = deductible;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public List<Driver> getDrivers() {
		return drivers;
	}

	public void setDrivers(List<Driver> drivers) {
		this.drivers = drivers;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
}
