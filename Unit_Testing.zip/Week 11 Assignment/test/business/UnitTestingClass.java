package business;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import beans.Coverage;
import beans.Driver;
import beans.Policy;
import beans.Vehicle;
import data.PolicyTestData;
import business.PolicyBO; 

public class UnitTestingClass {
	public PolicyTestData p = new PolicyTestData();
	
	@Test
	public void testPolicyData()
	{
		
//This section is using the provided Test Data.
		int counter = 1;	
while (counter < 4)  {
	String policyNumber = p.get(counter, counter).getPolicyNumber();
		assertEquals("ABC123", policyNumber , "Policy Number Fail");

	int policyDayOfWeek = p.get(counter, counter).getEffectiveDate().getFirstDayOfWeek();
		assertEquals(1, policyDayOfWeek, "Policy Day of the Week Fail");

	int policyYear = p.get(counter, counter).getEffectiveDate().getWeekYear();
			assertEquals(2018, policyYear, "Policy Year Fail");

	int deduct = p.get(counter, counter).getDeductible();
			assertEquals(500, deduct, "Policy Deductible Fail");
	
	String state = p.get(counter, counter).getState();
			assertEquals("WI", state, "Policy State Fail");

			counter ++;
	}

//This section is testing the setters with a different set of data.
	Policy setPolicyTest = new Policy();
	List<Driver> drivers = new ArrayList<Driver>();
	List<Vehicle> vehicles = new ArrayList<Vehicle>();

		drivers.add(new Driver("Hanz", "Sans", PolicyTestData.createDate(1984, Calendar.JANUARY, 31), "M", 1, 2));
		drivers.add(new Driver("Panz", "Shorty", PolicyTestData.createDate(1965, Calendar.DECEMBER, 13), "F", 4, 6));
 
		vehicles.add(new Vehicle("Kia", "Sport", 2010, "Personal", 100000, new Coverage(1500000, 11000000, 150000)));
		vehicles.add(new Vehicle("Kia", "Sport", 2010, "Personal", 100000, new Coverage(1500000, 11000000, 150000)));


		setPolicyTest.setPolicyNumber("XYZ098");
			assertEquals("XYZ098", setPolicyTest.getPolicyNumber());

		setPolicyTest.setEffectiveDate(Calendar.getInstance());
			assertEquals(Calendar.getInstance(), setPolicyTest.getEffectiveDate());

		setPolicyTest.setDeductible(800);
			assertEquals(800, setPolicyTest.getDeductible());

		setPolicyTest.setState("CO");
			assertEquals("CO", setPolicyTest.getState());

		setPolicyTest.setDrivers(drivers);
			assertEquals(drivers, setPolicyTest.getDrivers());

		setPolicyTest.setVehicles(vehicles);
			assertEquals(vehicles, setPolicyTest.getVehicles());
			

}

@Test
public void testDriverData() {
	
	//This section is using the provided Test Data.
    List<Driver> Drivers = p.get(3, 3).getDrivers();
    
    int DriverCounter = 0;
    while (DriverCounter < 3) {
    
    	String firstDriver = Drivers.get(DriverCounter).getFirstName();
    	String lastDriver = Drivers.get(DriverCounter).getLastName();
    	int birthdayDriver = Drivers.get(DriverCounter).getBirthDate().getWeekYear();
    	String genderDriver = Drivers.get(DriverCounter).getGender();
    	int ticketsDriver = Drivers.get(DriverCounter).getTickets();
    	int accidentsDriver = Drivers.get(DriverCounter).getAccidents();
    
    if (DriverCounter == 0)
    {
    	assertAll("Driver1",
    			() -> assertEquals("John", firstDriver),
    			() -> assertEquals("Doe", lastDriver),
    			() -> assertEquals(1970, birthdayDriver),
    			() -> assertEquals("M", genderDriver),
    			() -> assertEquals(0, ticketsDriver),
    			() -> assertEquals(0, accidentsDriver)
    			);    	

    }
    else if (DriverCounter == 1)
    {
    	assertAll("Driver2",
    			() -> assertEquals("Jane", firstDriver),
    			() -> assertEquals("Doe", lastDriver),
    			() -> assertEquals(1982, birthdayDriver),
    			() -> assertEquals("F", genderDriver),
    			() -> assertEquals(0, ticketsDriver),
    			() -> assertEquals(0, accidentsDriver)
    			); 

    }
    else
    {
    	assertAll("Driver3",
    			() -> assertEquals("Jim", firstDriver),
    			() -> assertEquals("Doe", lastDriver),
    			() -> assertEquals(1999, birthdayDriver),
    			() -> assertEquals("M", genderDriver),
    			() -> assertEquals(2, ticketsDriver),
    			() -> assertEquals(1, accidentsDriver)
    			);

    }
    DriverCounter++;
    }

//This section is testing the setters with a different set of data.
    
    Driver setDriverTest = new Driver();
    
    setDriverTest.setFirstName("Hans");
    	assertEquals("Hans", setDriverTest.getFirstName());
    setDriverTest.setLastName("Franz");
    	assertEquals("Franz", setDriverTest.getLastName());
    setDriverTest.setBirthDate(Calendar.getInstance());
    	assertEquals(Calendar.getInstance(), setDriverTest.getBirthDate());
    setDriverTest.setGender("M");
    	assertEquals("M", setDriverTest.getGender());
    setDriverTest.setTickets(2);
    	assertEquals(2, setDriverTest.getTickets());
    setDriverTest.setAccidents(1);
    	assertEquals(1, setDriverTest.getAccidents());
        
    }

@Test
public void testVehicleData() {

//This section is using the provided Test Data.
    List<Vehicle> Vehicles = p.get(3, 3).getVehicles();
    int VehicleCounter = 0;
    while (VehicleCounter < 3) {
    
    	String makeVehicle = Vehicles.get(VehicleCounter).getMake();
    	String modelVehicle = Vehicles.get(VehicleCounter).getModel();
    	int yearVehicle = Vehicles.get(VehicleCounter).getYear();
    	String usageVehicle = Vehicles.get(VehicleCounter).getUsage();
    	int milesVehicle = Vehicles.get(VehicleCounter).getMilesPerYear();
    	
    	Coverage coverageVehicle = Vehicles.get(VehicleCounter).getCoverage();
    		int liabilityCoverageVehicle = coverageVehicle.getLiabilityLimit();
    		int propertyDamageLimitVehicle = coverageVehicle.getPropertyDamageLimit();
    		int uninsuredMotoristLimitVehicle = coverageVehicle.getUninsuredMotoristLimit();
    	
    if (VehicleCounter == 0)
    {
    	assertAll("Vehicle1",
    			() -> assertEquals("Honda", makeVehicle),
    			() -> assertEquals("Accord", modelVehicle),
    			() -> assertEquals(2010, yearVehicle),
    			() -> assertEquals("Personal", usageVehicle),
    			() -> assertEquals(10000, milesVehicle),
    			() -> assertEquals(500000, liabilityCoverageVehicle),
    			() -> assertEquals(1000000, propertyDamageLimitVehicle),
    			() -> assertEquals(50000, uninsuredMotoristLimitVehicle)
    			);    	

    }
    else if (VehicleCounter == 1)
    {
    	assertAll("Vehicle2",
    			() -> assertEquals("Audi", makeVehicle),
    			() -> assertEquals("A6", modelVehicle),
    			() -> assertEquals(2014, yearVehicle),
    			() -> assertEquals("Personal", usageVehicle),
    			() -> assertEquals(15000, milesVehicle),
    			() -> assertEquals(500000, liabilityCoverageVehicle),
    			() -> assertEquals(1000000, propertyDamageLimitVehicle),
    			() -> assertEquals(50000, uninsuredMotoristLimitVehicle)
    			); 

    }
    else
    {
    	assertAll("Vehicle3",
    			() -> assertEquals("Chevrolet", makeVehicle),
    			() -> assertEquals("Malibu", modelVehicle),
    			() -> assertEquals(2001, yearVehicle),
    			() -> assertEquals("Personal", usageVehicle),
    			() -> assertEquals(5000, milesVehicle),
    			() -> assertEquals(25000, liabilityCoverageVehicle),
    			() -> assertEquals(50000, propertyDamageLimitVehicle),
    			() -> assertEquals(25000, uninsuredMotoristLimitVehicle)
    			);

    }
    VehicleCounter++;
    }
    
//This section is testing the setters with a different set of data.    
    Vehicle setVehicleTest = new Vehicle();
    Coverage coverageTest = new Coverage(1500000, 11000000, 150000);
    
    setVehicleTest.setMake("Kia");
    	assertEquals("Kia", setVehicleTest.getMake());
    setVehicleTest.setModel("Sport");
    	assertEquals("Sport", setVehicleTest.getModel());
    setVehicleTest.setYear(2010);
    	assertEquals(2010, setVehicleTest.getYear());
    setVehicleTest.setUsage("Personal");
    	assertEquals("Personal", setVehicleTest.getUsage());
    setVehicleTest.setMilesPerYear(10000);
    	assertEquals(10000, setVehicleTest.getMilesPerYear());
    setVehicleTest.setCoverage(coverageTest);
    	assertEquals(coverageTest, setVehicleTest.getCoverage());
    
    }

//This function tests the Coverage class with a different set of data only since it is covered in the Vehicles Class.
@Test
public void testCoverageData() {
    	Coverage coverageTest = new Coverage();
    	
    	coverageTest.setLiabilityLimit(50000);
    		assertEquals(50000, coverageTest.getLiabilityLimit());    	
    	coverageTest.setPropertyDamageLimit(350000);
    		assertEquals(350000, coverageTest.getPropertyDamageLimit());
    	coverageTest.setUninsuredMotoristLimit(60000);
    		assertEquals(60000, coverageTest.getUninsuredMotoristLimit());
    }

@Test
public void testPremiumCalc(){
	List<Driver> drivers = new ArrayList<Driver>();
	List<Vehicle> vehicles = new ArrayList<Vehicle>();
	PolicyBO pBO = new PolicyBO();
	
		drivers.add(new Driver("Hanz", "Sans", PolicyTestData.createDate(2001, Calendar.JANUARY, 31), "M", 1, 2));
		drivers.add(new Driver("Panz", "Shorty", PolicyTestData.createDate(1985, Calendar.DECEMBER, 13), "F", 4, 6));
 
		vehicles.add(new Vehicle("Cadillac", "Escalade", 2010, "Personal", 100000, new Coverage(1500000, 11000000, 150000)));
		vehicles.add(new Vehicle("Munts", "Jet", 2017, "Personal", 100000, new Coverage(1500000, 11000000, 150000)));
		
		float premRateV1 = pBO.calculatePremium(vehicles.get(0));
			assertEquals(87.5, premRateV1);
		float premRateV2 = pBO.calculatePremium(vehicles.get(1));
			assertEquals(50.0, premRateV2);
		float premRateV3 = pBO.calculatePremium(new Vehicle("BMW", "6", 2017, "Personal", 100000, new Coverage(1500000, 11000000, 150000)));
			assertEquals(100.0, premRateV3);				
		float premRateD = pBO.calculatePremium(drivers.get(0), Calendar.getInstance());
			assertEquals(125.0, premRateD);
		
//Testing provided Test data		
	Policy premiumPolicy1 = p.get(1, 1);
		int premiumTotal1 = PolicyBO.calculatePremium(premiumPolicy1);
		assertEquals(93, premiumTotal1);
	Policy premiumPolicy2 = p.get(2, 2);
		int premiumTotal2 = PolicyBO.calculatePremium(premiumPolicy2);
			assertEquals(230, premiumTotal2);
	Policy premiumPolicy3 = p.get(3, 3);
		int premiumTotal3 = PolicyBO.calculatePremium(premiumPolicy3);
				assertEquals(368, premiumTotal3);				
				
	Policy premiumPolicy4 = new Policy("ABC123", Calendar.getInstance(), 500, "WI", drivers, vehicles);
		int premiumTotal4 = PolicyBO.calculatePremium(premiumPolicy4);
			assertEquals(313, premiumTotal4);
}

}
