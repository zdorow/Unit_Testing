package data;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import beans.Coverage;
import beans.Driver;
import beans.Policy;
import beans.Vehicle;

public class PolicyTestData {

	public Policy get(int numDrivers, int numVehicles) {
		
		List<Driver> drivers = new ArrayList<Driver>();
		List<Vehicle> vehicles = new ArrayList<Vehicle>();
		Policy policy = new Policy("ABC123", createDate(2018, Calendar.JANUARY, 1), 500, "WI", drivers, vehicles);

		if (numDrivers >= 1)
			drivers.add(new Driver("John", "Doe", createDate(1970, Calendar.FEBRUARY, 2), "M", 0, 0));
		
		if (numDrivers >= 2)
			drivers.add(new Driver("Jane", "Doe", createDate(1982, Calendar.MARCH, 3), "F", 0, 0));
		
		if (numDrivers >= 3)
			drivers.add(new Driver("Jim", "Doe", createDate(1999, Calendar.APRIL, 1), "M", 2, 1));

		if (numVehicles >= 1)
			vehicles.add(new Vehicle("Honda", "Accord", 2010, "Personal", 10000, new Coverage(500000, 1000000, 50000)));
		
		if (numVehicles >= 2)
			vehicles.add(new Vehicle("Audi", "A6", 2014, "Personal", 15000, new Coverage(500000, 1000000, 50000)));
		
		if (numVehicles >= 3)
			vehicles.add(new Vehicle("Chevrolet", "Malibu", 2001, "Personal", 5000, new Coverage(25000, 50000, 25000)));

		return policy;
	}

	public static Calendar createDate(int year, int month, int day) {
		Calendar date = Calendar.getInstance();

		date.set(Calendar.YEAR, year);
		date.set(Calendar.MONTH, month);
		date.set(Calendar.DAY_OF_MONTH, day);

		return date;
	}
}
